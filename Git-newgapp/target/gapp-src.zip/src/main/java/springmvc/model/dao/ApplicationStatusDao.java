package springmvc.model.dao;

public class ApplicationStatusDao {

}
