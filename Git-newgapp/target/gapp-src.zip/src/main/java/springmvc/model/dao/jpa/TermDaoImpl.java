package springmvc.model.dao.jpa;

public class TermDaoImpl {

}
