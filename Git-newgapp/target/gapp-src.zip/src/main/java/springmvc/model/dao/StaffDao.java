package springmvc.model.dao;

public class StaffDao {

}
